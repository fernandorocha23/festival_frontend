function HomeRegisto() {
    return(
        <div id="registo">
            <p>Está interessado?</p>
            <form action="/registo" target="_blank">
                <input type="submit" value="Registe-se Aqui!"/>
            </form>
        </div>
    )
}
export default HomeRegisto;