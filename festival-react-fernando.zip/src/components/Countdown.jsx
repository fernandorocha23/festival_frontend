import {useEffect, useState} from "react";

const Countdown = () =>{

    // Data/hora do festival (imaginando que este seria a 25 de agosto)
    const dataFestival = new Date("2025-08-14T21:30:00");
// Data/hora atual
    const dataAtual = new Date();
// Diferença entre as duas datas (em milisegundos)
    const diferenca = dataFestival - dataAtual;
// Extrair dias, horas, minutos e segundos –floor() serve para arredondar para baixo
    const getDias = () =>Math.floor(time / (1000 * 60 * 60 * 24));
    const getHoras = () => Math.floor((time % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const getMinutos = () => Math.floor((time % (1000 * 60 * 60)) / (1000 * 60));
    const getSegundos = () =>  Math.floor((time % (1000 * 60)) / 1000);

    const[time, setTime] = useState({diferenca});

    useEffect(() => {
        const interval= setInterval(() => {
            updateTime();
        }, 1000);
        return() => {
            clearInterval(interval);
        };
    }, )


    const updateTime = () => {
        setTime(diferenca);
    }

    return(
        <section>
            <h3 id="tempo">Faltam {getDias()} dias {getHoras()} horas {getMinutos()} minutos e {getSegundos()} segundos para o maior festival deste verão!!</h3>
        </section>
    )
}

export default Countdown;