function FormSubmit() {
    return(
        <div className="form-submit">
            <input id="botao-registo" type="submit" value="Registar"/>
        </div>
    )
}

export default FormSubmit;