function InqueritoIntroducao() {
    return(
        <>
            <div className="festival-introducao">
                <h1>Bem-vindo ao Sol da Caparica 2025!</h1>
                <p className="festival-slogan">Responda a este inquérito abaixo de forma a ficarmos a conhecer melhor os seus gostos e interesses</p>
            </div>

        </>
    )
}
export default InqueritoIntroducao;