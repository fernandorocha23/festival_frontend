import HomeIntroducao from "../components/HomeIntroducao.jsx";
import Header from "../components/Header.jsx";
import Footer from "../components/Footer.jsx";
import {Link, useLocation} from "react-router-dom";

function Temporario() {
    const location = useLocation();
    const dados = location.state.data;
    return (
        <>
            <Header/>
            <HomeIntroducao/>
            <h3 style={{ color: "black" }} className={"noticias-container"}>
                Foste registado com sucesso, {dados.user}!
                Irás receber um email de boas vindas em {dados.email}.
            </h3>
            <Footer/>
        </>
    )
}

export default Temporario;