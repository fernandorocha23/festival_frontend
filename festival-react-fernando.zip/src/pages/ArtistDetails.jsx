import Header from "../components/Header.jsx";
import Footer from "../components/Footer.jsx";
import {Link, useLocation} from "react-router-dom";
import artistInfoDetails from "../assets/json/comments.json"
import Artist from "../components/Artist.jsx";
import CommentArtist from "../components/CommentArtist.jsx";
import usersInfo from "../assets/json/users.json"

function ArtistDetails() {
    const comments = artistInfoDetails["comments"];
    const users = usersInfo["users"];

    const location = useLocation();
    const dados = location.state.data;

    return (
        <>
            <Header/>
            <main className={"artista-detalhes-container"}>
                <div className="artista-card">
                    <img src={dados.image_path} alt={dados.name}/>
                    <div className="artist-info">
                        <h1 className={"artista-nome"}>{dados.name}</h1>
                        <p className="artist-bio">{dados.short_bio}</p>
                        <div className={"performance-info"}>
                            <p><strong>Género:</strong>{dados.music_style}</p>
                            <p><strong>Data da performance:</strong> {dados.performance_date} - {dados.performance_hour}</p>
                            <p><strong>Palco:</strong> Principal</p>
                            <p><strong>Spotify:</strong>
                                <Link to={dados.video_url} target="_blank"> Carregue aqui para ouvir no Spotify</Link>
                            </p>
                        </div>
                    </div>
                </div>
                <section className="comment-section">
                    <h2>Comentários do artista</h2>
                    <div className="comments-list">
                        {comments
                            .filter((c) => c.artist_id === dados.id)
                            .map((c, index) => {
                                return (
                                    <CommentArtist
                                        key={index}
                                        artist_id={c.artist_id}
                                        user_id={c.user_id}
                                        comment_text={c.comment_text}
                                        pub_datetime={c.pub_datetime}
                                    />
                                );
                            })}
                    </div>
                </section>
            </main>
            <Footer/>
        </>
    )
}

export default ArtistDetails;