import {useUserContext} from "../services/UserContext.jsx";
import {useEffect, useState} from "react";
import api from "../services/api.jsx";

const UserComments = () =>{

    const  [comments, setComments] = useState([]);

    const contexto = useUserContext();

    useEffect(() => {
        async function fetchArtists() {
            let comentarios = await api.get("/user/comments")
            setComments(comentarios.data);
        }
        fetchArtists();
    }, []);

    return(
        <>
            <h1>Comentarios de {contexto.user.username}</h1>
            <ul>
                {comments.map((comment) => (
                    <li key={comment.id}>
                        <p><strong>{comment.artistName}</strong>: {comment.commentText}</p>
                        <p><em>{new Date(comment.dateTime).toLocaleString()}</em> | Likes: {comment.likesCount}</p>
                    </li>
                ))}
            </ul>
        </>

    )
}
export default UserComments;