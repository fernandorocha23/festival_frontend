import {useUserContext} from "./UserContext.jsx";
import {Navigate, Route} from "react-router-dom";
import {Children} from "react";

const ProtectedRoute = ({children}) => {
    const contexto = useUserContext();

    if(!contexto.user) {
        return <Navigate to="/login" replace/>;
    }

    return children;
}

export default ProtectedRoute;