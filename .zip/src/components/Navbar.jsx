import {Link} from "react-router-dom";

function Navbar(){
    return(
        <nav>
            <div>
                <ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/cartaz">Cartaz</Link></li>
                    <li><Link to="/registo">Registo</Link></li>
                    <li><Link to="/bilhetes">Bilheteira</Link></li>
                    <li><Link to="/inquerito">Inquérito</Link></li>
                </ul>
            </div>
        </nav>
    )
}
export default Navbar;