function CommentArtist(detalhes){
    return(
        <div className="comentarios">
            <h3>Comentário de user {detalhes.user_id}</h3>
            <p>{detalhes.comment_text}</p>
            <small><em>Publicado em: {detalhes.pub_datetime}</em></small>
        </div>
    )
}
export default CommentArtist;