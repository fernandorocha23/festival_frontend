
import Footer from "../components/Footer.jsx";
import Header from "../components/Header.jsx";
import Artist from "../components/Artist.jsx";

function Cartaz({artists}) {
    return (
        <>
            <Header/>
            <main className="general-container">

                <div className="festival-introducao">
                    <h1>Cartaz Oficial</h1>
                    <p className="festival-slogan">Confira aqui os artistas confirmados para o Sol da Caparica 2025!</p>
                </div>
                {artists.map( (a, index) => <Artist
                    key={index}
                    id={a.id}
                    name={a.name}
                    performance_date={a.performance_date}
                    performance_hour={a.performance_hour}
                    image_path={a.image_path}
                    video_url={a.video_url}
                    short_bio={a.short_bio}
                    music_style={a.music_style}
                />)}
            </main>
            <Footer/>
        </>
    )
}

export default Cartaz;