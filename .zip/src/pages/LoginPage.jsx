import api from "../services/api.jsx";
import {useState} from "react";
import Header from "../components/Header.jsx";
import Footer from "../components/Footer.jsx";
import {useUserContext} from "../services/UserContext.jsx";
import {useNavigate} from "react-router-dom";

const LoginPage = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("")
    const contexto = useUserContext();
    const navigate = useNavigate();

    async function handleSubmit(e) {
        e.preventDefault();

        const body = new FormData();
        body.set("username", username);
        body.set("password", password);

        await api.post("/login", body);

        let user = (await api.get("/user/logado")).data;
        contexto.setUser(user);

        navigate("/inquerito");
    }
    return (
        <>
            <Header/>
            <main className={"general-container"}>
                <h2>Welcome back</h2>
                <form onSubmit={handleSubmit}>
                    <input type="username" id="username" value={username} placeholder="Username" required
                           onChange={(e) => setUsername(e.target.value)} />
                    <input type="password" id="password" value={password} placeholder="Password" required
                           onChange={(e) => setPassword(e.target.value)}/>
                    <input type="submit" value={"login"}></input>
                </form>
            </main>
        <Footer/>
        </>
    )
}


export default LoginPage;